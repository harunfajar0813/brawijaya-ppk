﻿namespace projekakhir
{
    partial class frmDetailAspirasi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textJudulAspirasi = new System.Windows.Forms.TextBox();
            this.btnUpvote = new System.Windows.Forms.Button();
            this.btnDownvote = new System.Windows.Forms.Button();
            this.textDetailAspirasi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textJudulAspirasi
            // 
            this.textJudulAspirasi.Location = new System.Drawing.Point(125, 57);
            this.textJudulAspirasi.Multiline = true;
            this.textJudulAspirasi.Name = "textJudulAspirasi";
            this.textJudulAspirasi.Size = new System.Drawing.Size(469, 33);
            this.textJudulAspirasi.TabIndex = 0;
            // 
            // btnUpvote
            // 
            this.btnUpvote.Location = new System.Drawing.Point(28, 105);
            this.btnUpvote.Name = "btnUpvote";
            this.btnUpvote.Size = new System.Drawing.Size(75, 68);
            this.btnUpvote.TabIndex = 1;
            this.btnUpvote.Text = "Upvote";
            this.btnUpvote.UseVisualStyleBackColor = true;
            // 
            // btnDownvote
            // 
            this.btnDownvote.Location = new System.Drawing.Point(28, 191);
            this.btnDownvote.Name = "btnDownvote";
            this.btnDownvote.Size = new System.Drawing.Size(75, 66);
            this.btnDownvote.TabIndex = 2;
            this.btnDownvote.Text = "Downvote";
            this.btnDownvote.UseVisualStyleBackColor = true;
            // 
            // textDetailAspirasi
            // 
            this.textDetailAspirasi.Location = new System.Drawing.Point(125, 105);
            this.textDetailAspirasi.Multiline = true;
            this.textDetailAspirasi.Name = "textDetailAspirasi";
            this.textDetailAspirasi.Size = new System.Drawing.Size(469, 283);
            this.textDetailAspirasi.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(253, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Detail Aspirasi";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 414);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textDetailAspirasi);
            this.Controls.Add(this.btnDownvote);
            this.Controls.Add(this.btnUpvote);
            this.Controls.Add(this.textJudulAspirasi);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textJudulAspirasi;
        private System.Windows.Forms.Button btnUpvote;
        private System.Windows.Forms.Button btnDownvote;
        private System.Windows.Forms.TextBox textDetailAspirasi;
        private System.Windows.Forms.Label label1;
    }
}

