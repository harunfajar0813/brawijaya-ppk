<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Invoice;

class InvoiceController extends Controller
{
    public function index()
    {
        return response()->json(Invoice::all());
    }

    public function create(Request $request)
    {
        $createInvoice = new Invoice();
        $createInvoice->game_name = $request->input('game_name');
        $createInvoice->voucher_name = $request->input('voucher_name');
        $createInvoice->account_id = $request->input('account_id');
        $createInvoice->paypal_account = $request->input('paypal_account');
        $createInvoice->save();
        return response()->json($createInvoice, 201);
    }
}
